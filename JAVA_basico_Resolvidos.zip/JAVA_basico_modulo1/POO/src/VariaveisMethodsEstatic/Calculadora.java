package VariaveisMethodsEstatic;

public class Calculadora
{
	public static int sum(int a, int b)
	{
		return a+b;
	}
	public static int div(int a,int b)
	{
		return a/b;
	}
	public static int mult(int a,int b)
	{
		return a*b;
	}
	public static int potencia(int a,int b)
	{
		int pot=1;
		
		for(int i=1;i<=b;i++)
			pot*=a;
		return pot;
	}
	public static int fatorial(int num)
	{
		if(num ==1 || num ==0)
			return 1;
		else
			return num*fatorial(num-1);
	}
	

}
