package VariaveisMethodsEstatic;

import javax.swing.JOptionPane;

public class Teste {

	public static void main(String[] args) 
	{
		int n1=Integer.parseInt(JOptionPane.showInputDialog("Insira o primeiro inteiro:"));
		int n2=Integer.parseInt(JOptionPane.showInputDialog("Insira o segundo inteiro:"));
		String r="";
		
		r+="Soma:"+Calculadora.sum(n1, n2)+"\n"+"Divisao:"+Calculadora.div(n1, n2)+"Mult:"+Calculadora.mult(n1, n2)+"potencia:"+Calculadora.potencia(n1, n2);
		
		JOptionPane.showMessageDialog(null,r);
		
		System.out.println("Fatorial:"+Calculadora.fatorial(n1));
		
		
		
		
		
		

	}

}
