package MetEstaticUnidadeTempo;

import javax.swing.JOptionPane;

public class Teste {

	public static void main(String[] args) 
	{
		//Exemplo de conversao de dias para anos
		
		float dia =Float.parseFloat(JOptionPane.showInputDialog("Digite o dia:"));
		JOptionPane.showMessageDialog(null, dia+"equivale a:"+Times.DiasAnos(dia)+"anos");

	}

}
