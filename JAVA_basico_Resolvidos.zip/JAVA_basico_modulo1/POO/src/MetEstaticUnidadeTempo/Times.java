package MetEstaticUnidadeTempo;

public class Times 
{
	public static float minSeg(float min)
	{
		return min*60;
	}
	public static float segMin(float seg)
	{
		return seg/60f;
	}
	public static float horaMin(float m)
	{
		return m/60f;
	}
	public static float minHora(float h)
	{
		return h*60;
	}
	
	public static float dia_hora(float h)
	{
		return h/24f;
	}

	public static float hora_dia(float d)
	{
		return d*24;
	}

	public static float semDias(float d)
	{
		return d/7f;
	}
	public static float diaSem(float s)
	{
		return s*7;
	}
	
	public static float anoDias(float d)
	{
		return d/365.25f;
	}
	public static float DiasAnos(float a)
	{
		return a*365.25f;
	}



}
