package VariaveisMethodsEstat2;

public class ConversaoUnidadesArea 
{
	
	
	public static float PesQuadMetros(float pesQuad)
	{
		
		return pesQuad/10.76f;
	}
	
	public static float CentPesQuad(float cm)
	{
		
		return cm/929f;
	}
	
	public static float AcresMilha(float acres)
	{
		
		return acres/640f;
	}
	
	public static float PesQuadAcres(float pesQ)
	{
		
		return pesQ/43.560f;
	}
	
}
