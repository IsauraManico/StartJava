package VariaveisMethodsEstat2;

import java.util.Scanner;

public class Teste
{
	public static void main(String[]args)
	{
		Scanner in = new Scanner(System.in);
		System.out.println("Insira o valor :");
		float v=in.nextInt();
		
		System.out.println(ConversaoUnidadesArea.AcresMilha(v));
	}
	
	

}
