package MethosEstaticos1;

public class Teste {

	public static void main(String[] args)
	{
		//Contador contador = new Contador();
		Contador.num=10; //Com metodos estatics podemos chamar os atributos sem instanciar as classes
		Contador.incrementar();
		
		
		System.out.println(Contador.num);

	}

}
