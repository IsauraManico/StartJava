package MethosEstaticos1;

public class Contador 
{
	static int num;
	
	public Contador()
	{
		this.num++;
	}
	public static void zerar()
	{
		num=0;
	}
	public static void incrementar()
	{
		num++;
	}
	public static int retornar()
	{
		return num;
	}
	
	
}
