package HerancaPolimorfismo;

public class ContaBancaria
{

	private String nomeCliente;
	private String numConta;
	private float saldo;
	
	
	public String getNomeCliente()
	{
		return nomeCliente;
	}
	public void setNomeCliente(String nomeCliente)
	{
		this.nomeCliente = nomeCliente;
	}
	public String getNumConta()
	{
		return numConta;
	}
	public void setNumConta(String numConta)
	{
		this.numConta = numConta;
	}
	public float getSaldo()
	{
		return saldo;
	}
	public void setSaldo(float saldo)
	{
		this.saldo = saldo;
	}
	
	public void sacar(float valor)
	{
		this.saldo-=valor;
	}
	public void depositar(float valor)
	{
		this.saldo+=valor;
	}
}
