package HerancaPolimorfismo;

public class ContaEspecial extends ContaBancaria
{
	private float limite;

	public float getLimite() {
		return limite;
	}

	public void setLimite(float limite) {
		this.limite = limite;
	}
	
	public void sacar(float limite)
	{
		this.setSaldo(getSaldo()-limite);
	}

}
