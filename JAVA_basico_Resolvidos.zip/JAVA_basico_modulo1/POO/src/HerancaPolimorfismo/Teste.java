package HerancaPolimorfismo;

import java.util.Scanner;

public class Teste {

	public static void main(String[] args) 
	{
		ContaBancaria conta = new ContaBancaria();
		ContaPoupanca cp= new ContaPoupanca();
		ContaEspecial ce= new ContaEspecial();
		
		Scanner in = new Scanner(System.in);
		
		System.out.println("<<Crie uma conta Bancaria: ContaPoupanca(CP) ou ContaEspecial(CE)>>");
		String op=in.next();
		float saldo;
		float valSacar;
		float depo;
		float rend;
		String nome;
		float limite;
		String numConta;
		
		switch(op)
		{
		case "CP":
			System.out.println("Foi criada a conta poupanca!!");
			System.out.println("Insira seu nome:");
			nome=in.next();
			cp.setNomeCliente(nome);
			System.out.println("Insira o numero da conta:");
			numConta=in.next();
			cp.setNumConta(numConta);
			System.out.println("Insira seu saldo:");
			saldo=in.nextFloat();
			System.out.println("Insira o valor a sacar:");
			valSacar=in.nextFloat();
			cp.sacar(valSacar);
			System.out.println("Insira o valor a depositar:");
			depo=in.nextFloat();
			System.out.println("Insira o rendimmento:");
			rend=in.nextFloat();
			cp.calcularNovoSaldo(rend);
			
			System.out.println("Conta poupanca \n"+"Nome:"+cp.getNomeCliente()+"Numero conta:"+cp.getNumConta()+"Saldo"+cp.getSaldo());
			System.out.println("Novo saldo"+cp.getDiaRedindimento());
			break;
		case "CE":
			System.out.println("Foi criada a conta especial!!");
			System.out.println("Insira seu nome:");
			nome=in.next();
			ce.setNomeCliente(nome);
			System.out.println("Insira o numero da conta:");
			numConta=in.next();
			cp.setNumConta(numConta);
			saldo=in.nextFloat();
			System.out.println("Insira o valor a sacar:");
			valSacar=in.nextFloat();
			ce.sacar(valSacar);
			System.out.println("Insira o valor a depositar:");
			depo=in.nextFloat();
			System.out.println("Insira o rendimmento:");
			rend=in.nextFloat();
			System.out.println("Insira o seu limite:");
			limite=in.nextFloat();
			System.out.println("Conta poupanca \n"+"Numero da conta:"+ce.getNumConta()+"Nome:"+cp.getNomeCliente()+"Saldo"+cp.getSaldo());
			System.out.println("Limite:"+ce.getLimite()+"Sacar:"+ce.getSaldo());
			
			
			break;
			default:
				System.out.println("error");
			
		}
		

	}

}
