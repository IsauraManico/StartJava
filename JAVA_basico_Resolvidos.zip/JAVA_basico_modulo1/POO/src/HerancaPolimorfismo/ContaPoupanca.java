package HerancaPolimorfismo;

public class ContaPoupanca extends ContaBancaria
{
	private float diaRedindimento;
	
	public void calcularNovoSaldo(float diaRedindimento)
	{
		this.setSaldo(getSaldo()*diaRedindimento/100f);
		
	}

	public float getDiaRedindimento() {
		return diaRedindimento;
	}

	public void setDiaRedindimento(float diaRedindimento) {
		this.diaRedindimento = diaRedindimento;
	}
	
	

}
