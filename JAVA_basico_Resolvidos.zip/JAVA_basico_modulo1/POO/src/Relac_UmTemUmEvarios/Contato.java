apackage LicaoDeCasa;

public class Contato
{
	private String nomeCont,telefone,email;

	public String getNomeCont() {
		return nomeCont;
	}

	public void setNomeCont(String nomeCont) {
		this.nomeCont = nomeCont;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "Contato [nomeCont=" + nomeCont + ", telefone=" + telefone + ", email=" + email + "]";
	}
	
	public void imprimir(Contato x)
	{
		
			System.out.println("Suas informacoes:"+x);
	
	}
	
	

}
