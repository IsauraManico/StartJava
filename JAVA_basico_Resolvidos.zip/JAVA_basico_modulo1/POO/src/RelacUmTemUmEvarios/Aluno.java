package Licao2;

import java.util.Arrays;

public class Aluno
{

	private String nomeAluno,matricula;
	
	
	@Override
	public String toString() {
		return "Aluno [nomeAluno=" + nomeAluno + ", matricula=" + matricula ;
	}
	public String getNomeAluno() {
		return nomeAluno;
	}
	public void setNomeAluno(String nomeAluno) {
		this.nomeAluno = nomeAluno;
	}
	public String getMatricula() {
		return matricula;
	}
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	public float[] getNotas() {
		return notas;
	}
	public void setNotas(float[] notas) {
		this.notas = notas;
	}
	private float []notas;
}
