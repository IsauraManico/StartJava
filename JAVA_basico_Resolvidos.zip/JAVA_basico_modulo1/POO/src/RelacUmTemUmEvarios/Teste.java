package Licao2;

import java.util.*;

public class Teste {
	
	static Scanner input = new Scanner(System.in);
	
	public static void main(String[] args) 
	{
		 float med1,med2,med3,med4;
		 med1=0;
		 med2=0;
		 med3=0;
		 med4=0;
		 float[] n1=new float[4];
		 float[] n2=new float[4];
		 float[] n3=new float[4];
		 float[] n4=new float[4];
		
		System.out.println("Insira o nome do curso:");
		String name=input.nextLine();
		System.out.println("Insira o horario do curso:");
		String hora=input.nextLine();
		
		Curso curso = new Curso(name,hora);
		
		Professor prof = new Professor();
		
		System.out.println("Insira o nome do professor:");
		String nomeProf=input.nextLine();
		prof.setNomeProf(nomeProf);
		System.out.println("Insira o nome do departamento:");
		String departamento=input.nextLine();
		prof.setDepartamento(departamento);
		System.out.println("Insira o email:");
		String em=input.nextLine();
		prof.setEmail(em);
		curso.setProfessor(prof);
		System.out.println(prof.toString());
		
		Aluno al1= new Aluno();
		System.out.println("Insira o nome do primeiro aluno:");
		String nomeAluno1=input.nextLine();
		al1.setNomeAluno(nomeAluno1);
		System.out.println("Insira a matricula:");
		String matricula1=input.nextLine();
		al1.setMatricula(matricula1);
		
		for(int i=0;i<4;i++)
		{
			
			System.out.println("Insira as 4 notas:");
			n1[i]=input.nextFloat();
			med1+=n1[i]/4;
			al1.setNotas(n1);
				
			
		}
		for(int i=0;i<n1.length;i++) {
			System.out.println("Notas["+i+"]="+n1[i]);
		}
		
		System.out.println("A media:"+med1);
		if(med1>=7)
			System.out.println("Esta aprovado");
		else
			System.out.println("Esta  reprovado");
		
		
		Aluno al2= new Aluno();
		System.out.println("Insira o nome do segundo aluno:");
		String nomeAluno2=input.next();
		al2.setNomeAluno(nomeAluno2);
		System.out.println("Insira a matricula:");
		String matricula2=input.next();
		al2.setMatricula(matricula2);
		
		for(int i=0;i<4;i++)
		{
			
			System.out.println("Insira as 4 notas:");
			n2[i]=input.nextFloat();
			med2+=n2[i]/4;
			al2.setNotas(n2);
			//System.out.println("Notas["+i+"]="+n2[i]);
			
		}
		for(int i=0;i<n2.length;i++) {
			System.out.println("Notas["+i+"]="+n2[i]);
		}
		System.out.println("A media:"+med2);
		if(med2>=7)
			System.out.println("Esta aprovado");
		else
			System.out.println("Esta  reprovado");
		
		Aluno al3= new Aluno();
		System.out.println("Insira o nome do terceiro aluno:");
		String nomeAluno3=input.next();
		al3.setNomeAluno(nomeAluno3);
		System.out.println("Insira a matricula:");
		String matricula3=input.next();
		al3.setMatricula(matricula3);
		
		for(int i=0;i<4;i++)
		{				
			System.out.println("Insira as 4 notas:");
			n3[i]=input.nextFloat();
			med3+=n3[i]/4;
			al3.setNotas(n3);
			
			//System.out.println("Notas["+i+"]="+n3[i]);
		}
		for(int i=0;i<n3.length;i++)
		{
			System.out.println("Notas["+i+"]="+n3[i]);
		}
		System.out.println("A media:"+med3);

		if(med3>=7)
			System.out.println("Esta aprovado");
		else
			System.out.println("Esta  reprovado");
		
		Aluno al4= new Aluno();
		System.out.println("Insira o nome do quarto aluno:");
		String nomeAluno4=input.next();
		al4.setNomeAluno(nomeAluno4);
		System.out.println("Insira a matricula:");
		String matricula4=input.next();
		al4.setMatricula(matricula4);
		
		for(int i=0;i<4;i++)
		{
			
			System.out.println("Insira as 4 notas:");
			n4[i]=input.nextFloat();
			med4+=n4[i]/4;
			al4.setNotas(n4);
		}
		for(int i=0;i<n4.length;i++) {
			System.out.println("Notas["+i+"]="+n4[i]);
		}
		System.out.println("A media:"+med4);

		if(med4>=7)
			System.out.println("Esta aprovado");
		else
			System.out.println("Esta  reprovado");
		
		Aluno[] alunos = new Aluno[4];
		alunos[0]=al1;
		alunos[1]=al2;
		alunos[2]=al3;
		alunos[3]=al4;
		
		curso.setAlunos(alunos);
		
		if(curso !=null && curso.getAlunos()!= null)
		{
			for(Aluno a:curso.getAlunos())
			{
				System.out.println(a.toString());
				
				
			}
			//System.out.println(curso.toString());
			System.out.println("A media da turma:"+(med1+med2+med3+med4)/4);
		}
		
		
		
		
		

	}

}
