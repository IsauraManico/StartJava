package agenda;

public class Agenda 
{
	
	
	private String nomeAg;
	private Contato[] contatos;
	
	public Agenda(String nomeAg)
	{
		this.nomeAg =nomeAg;
	}
	public String getNomeAg() {
		return nomeAg;
	}
	public void setNomeAg(String nomeAg) {
		this.nomeAg = nomeAg;
	}
	public Contato[] getContatos() {
		return contatos;
	}
	public void setContatos(Contato[] contatos) {
		this.contatos = contatos;
	}
	
	

}