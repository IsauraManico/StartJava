package agenda;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class Teste {
    
    static Scanner in = new Scanner(System.in);
    static String nom;

	public static void main(String[] args) 
	{
                
		
		String nomeAg=JOptionPane.showInputDialog("Digite o nome da Agenda:");
		Agenda agenda = new Agenda(nomeAg);
		//agenda.setNomeAg(nomeAg);
		
		JOptionPane.showMessageDialog(null, "---------------Entre com 3 contatos-------------");
		
		JOptionPane.showMessageDialog(null,"--------Insira as informacoes no primeiro contato:-----");
		Contato c = new Contato();
		String email=JOptionPane.showInputDialog("Insira o email:");
		c.setEmail(email);
		String nomeC=JOptionPane.showInputDialog("Insira o nome do contato:");
		c.setNomeCont(nomeC);
		String num=JOptionPane.showInputDialog("Insira o numero de telefone:");
		c.setTelefone(num);
		c.imprimir(c);
		
		JOptionPane.showMessageDialog(null,"--------Insira as informacoes no segundo contato:-----");
		Contato c1 = new Contato();
		String em=JOptionPane.showInputDialog("Insira o email:");
		c1.setEmail(em);
		String nom=JOptionPane.showInputDialog("Insira o nome do contato:");
		c1.setNomeCont(nom);
		String n=JOptionPane.showInputDialog("Insira o numero de telefone:");
		c1.setTelefone(n);
		c1.imprimir(c1);
		
		JOptionPane.showMessageDialog(null,"--------Insira as informacoes no terceiro contato:-----");
		Contato c2 = new Contato();
		String ema=JOptionPane.showInputDialog("Insira o email:");
		c2.setEmail(ema);
		String nome=JOptionPane.showInputDialog("Insira o nome do contato:");
		c2.setNomeCont(nome);
		String nu=JOptionPane.showInputDialog("Insira o numero de telefone:");
		c2.setTelefone(nu);
		c2.imprimir(c2);
		
		Contato []contatos = new Contato[3];
		contatos[0]=c;
		contatos[1]=c1;
		contatos[2]=c2;
		
		agenda.setContatos(contatos);
		
		if(agenda !=null && agenda.getContatos() !=null)
		{
			for(Contato con:agenda.getContatos())
			{
				System.out.println("<<Imprimindo todos os contatos>>");
				System.out.println(con.toString());
			}
		}
                
                System.out.println("Insira o nome que pretendes buscar na agenda:");
                nom=in.next();
                System.out.println("Buscando o elemento:"+buscaContatoNome(nom,contatos));
	}
        
        public static int buscaContatoNome(String nome,Contato []c)
        {
            for(int i=0;i<c.length;i++)
            {
                if(c[i].getNomeCont().equals(nome))
                return i;  
              
            }
             return -1;
            
        }

}