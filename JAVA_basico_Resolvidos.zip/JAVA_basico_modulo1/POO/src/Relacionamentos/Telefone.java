package Relacionamentos;

public class Telefone 
{
	private String numTel,tipo,ddd;

	public String getNumTel() {
		return numTel;
	}

	public void setNumTel(String numTel) {
		this.numTel = numTel;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getDdd() {
		return ddd;
	}

	public void setDdd(String ddd) {
		this.ddd = ddd;
	}

	@Override
	public String toString() {
		return "Telefone [numTel=" + numTel + ", tipo=" + tipo + ", ddd=" + ddd + "]";
	}
	
	
	

}
