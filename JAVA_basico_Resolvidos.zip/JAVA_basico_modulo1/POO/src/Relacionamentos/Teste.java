package Relacionamentos;

public class Teste {

	public static void main(String[] args) 
	{
		
		
		Contato contato = new Contato();
		//contato.setEndereco("Camama1");
		Endereco end = new Endereco();
		
		end.setCidade("Luanda");
		end.setComplemento(null);
		end.setEstado("San");
		end.setNomeRua(";Anturios");
		end.setNumero(12);
		end.setCep("4445gg");
		
		
		contato.setNome("Isaura");
		//contato.setTelefone("995466013");
		
		Telefone tel = new Telefone();
		tel.setDdd("1234Isa");
		tel.setNumTel("9999999");
		tel.setTipo("Celular");
		
		Telefone tel1 = new Telefone();
		tel1.setDdd("14567Pulo");
		tel1.setNumTel("7777");
		tel1.setTipo("privado");
		
		//contato.setTelefones(telefones[2]);
		Telefone[] telefones = new Telefone[2];
		telefones[0]=tel;
		telefones[1]=tel1;
		
		
		//contato.setTelefone(tel);
		contato.setEndereco(end);
		contato.setTelefones(telefones);
		
		if(contato!=null && contato.getEndereco()!=null)
		{
			
			System.out.println(contato.getEndereco().getCep()); //feito pela Loiane
			
			//System.out.println(contato.getEndereco().toString()); Feito por mim Isaura A ntonio;
				
		}
		System.out.println(contato.getNome());
		//System.out.println(contato.getTelefone());
		
		/*if(contato!=null && contato.getTelefone()!=null)
		{
			
			System.out.println(contato.getTelefone().getTipo()); //feito pela Loiane
			
			//System.out.println(contato.getTelefone().toString()); Feito por mim Isaura A ntonio;
			//podemos gerar o tostring   
				
		}*/
		
		if(contato!=null && contato.getTelefones()!=null)
		{
			for(Telefone t: contato.getTelefones())
			{
				System.out.println(t.getDdd());
				System.out.println(t.toString());
			}
		}
		
		
	
		
		
		

	}

}
