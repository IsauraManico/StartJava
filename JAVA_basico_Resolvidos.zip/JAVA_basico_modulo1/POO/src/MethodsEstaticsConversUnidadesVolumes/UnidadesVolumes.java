package MethodsEstaticsConversUnidadesVolumes;

public class UnidadesVolumes
{
	public static float CmCubico_Litros(float cmCub)
	{
		return cmCub/1000f;
	}
	public static float litrosMetrosCub(float litro)
	{
		return litro/1000f;
	}
	public static float pescub_metroCubico(float pes)
	{
		return pes/35.32f;
	}
	public static float polegadasCubGalaoAmeric(float polegaCub)
	{
		return polegaCub/231f;
	}
	public static float litros_GalaoAmer(float litros)
	{
		return litros/3.785f;
	}
}
