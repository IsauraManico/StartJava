package MethodsEstaticsConversUnidadesVolumes;

import javax.swing.JOptionPane;

public class Teste {

	public static void main(String[] args) 
	{
		float valor = Float.parseFloat(JOptionPane.showInputDialog("Entre com o valor da unidade:"));
		//teste de CmCubico para Litros
		JOptionPane.showMessageDialog(null,+valor+"cm3 equivale:"+UnidadesVolumes.CmCubico_Litros(valor)+"litros");

	}

}
