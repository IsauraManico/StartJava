package HerancaAnimais;

public class Peixe extends Animais
{
	private String caract;

	public String getCaract() {
		return caract;
	}

	public void setCaract(String caract) {
		this.caract = caract;
	}
}
