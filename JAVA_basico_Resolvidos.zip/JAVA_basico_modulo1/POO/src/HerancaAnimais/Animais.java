package HerancaAnimais;

public class Animais
{
	public Animais()
	{
		System.out.println("--Zoo---");
	}
	@Override
	public String toString() {
		return "Animais [nome=" + nome + ", comprimento=" + comprimento + ", cor=" + cor + ", ambiente=" + ambiente
				+ ", velocidade=" + velocidade + ", numPatas=" + numPatas + "]";
	}
	private String nome, comprimento,cor, ambiente,velocidade;
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getComprimento() {
		return comprimento;
	}
	public void setComprimento(String comprimento) {
		this.comprimento = comprimento;
	}
	public String getCor() {
		return cor;
	}
	public void setCor(String cor) {
		this.cor = cor;
	}
	public String getAmbiente() {
		return ambiente;
	}
	public void setAmbiente(String ambiente) {
		this.ambiente = ambiente;
	}
	public String getVelocidade() {
		return velocidade;
	}
	public void setVelocidade(String velocidade) {
		this.velocidade = velocidade;
	}
	public int getNumPatas() {
		return numPatas;
	}
	public void setNumPatas(int numPatas) {
		this.numPatas = numPatas;
	}
	private int numPatas;
	
	

}
