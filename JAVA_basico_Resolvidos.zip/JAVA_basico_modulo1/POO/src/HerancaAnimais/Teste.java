package HerancaAnimais;

public class Teste {

	public static void main(String[] args) 
	{
		Animais animal=new Mamifero();
		animal.setNome("Camelo");
		animal.setComprimento("1500 cm");
		animal.setNumPatas(4);
		animal.setAmbiente("Terra");
		animal.setCor("Amarelo");
		animal.setVelocidade("2.0 m/s");
		
		Animais animal2 = new Peixe();
		animal2.setNome("Tubarao");
		animal2.setComprimento("300 cm");
		animal2.setNumPatas(0);
		animal2.setAmbiente("Mar");
		animal2.setCor("Azul");
		animal2.setVelocidade("1.5 m/s");
		
		Animais animal3 = new Mamifero();
		animal3.setNome("Urso do canada");
		animal3.setComprimento("180 cm");
		animal3.setNumPatas(4);
		animal3.setAmbiente("Terra");
		animal3.setCor("Mel");
		animal3.setVelocidade("0.5 m/s");
		
		System.out.println("As informacoes do Camelo:"+animal.toString());
		System.out.println("------------------------------------------------------------------------------");
		System.out.println("As informacoes do Peixe:"+animal2.toString());
		System.out.println("------------------------------------------------------------------------------");
		System.out.println("As informacoes do Urso canada:"+animal3.toString());
		
		
		
		
		
		
		
		

	}

}
