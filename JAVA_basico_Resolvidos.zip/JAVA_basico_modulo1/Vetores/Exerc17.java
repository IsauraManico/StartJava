import org.w3c.dom.ls.LSOutput;

import java.util.Scanner;

public class Exerc17
{
    public static  void main(String[] args)
    {

        Scanner in = new Scanner(System.in);
        int q=0;
        System.out.println("Insira o total de  idades:");
        int tot=in.nextInt();

        int a[] = new int[tot];

        for (int i=0;i<tot;i++)
        {
                System.out.println("Insira as idades:");
                a[i]=in.nextInt();

                if(a[i]>35)
                    q++;

        }
        for (int x:a)
        {
            if(x>35)
            {

                System.out.println("os elements maiores que 35:"+x);
                System.out.println("quant:"+q);

            }


        }

    }
}
