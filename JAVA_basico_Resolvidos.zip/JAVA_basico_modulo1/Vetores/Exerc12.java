import java.util.Scanner;

public class Exerc12
{
    public static int sum(int[] a)
    {
        int s=0;

        for (int i=0;i<10;i++)
        {
            s+=a[i];
        }
        return s;
    }

    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        int a[] = new int[10];

        for (int i=0;i<10;i++)
        {
            System.out.println("Digite os elementos no vetor:");
            a[i]=input.nextInt();

        }
        System.out.println("A soma dos elementos:"+sum(a));


    }
}
