import java.util.Scanner;


public class Exercvet19
{
    static Scanner input = new Scanner(System.in);
    static float[] result= new float[10];
    public static void main(String[] args)
    {
        float nota1[] = new float[2];
        float nota2[] =new float[2];
        String alunos[] = new String[10];

        for (int i=0;i<10;i++)
        {
            System.out.println("Digite o nome do aluno["+i+"]:");
            alunos[i]=input.next();

            System.out.println("Insira a primeira nota :");
            nota1[1]=input.nextFloat();
            System.out.println("Insira a segunda nota:");
            nota2[1]=input.nextFloat();

            result[i]=(nota1[1]+nota2[1])/2;
            System.out.println("A media do aluno:"+alunos[i]+"is"+result[i]);

            if(result[i]>=7)
                System.out.println("O aluno"+alunos[i]+"Esta aprovado");
            else
                System.out.println("o aluno"+alunos[i]+"Esta reprovado");





        }


    }
}
