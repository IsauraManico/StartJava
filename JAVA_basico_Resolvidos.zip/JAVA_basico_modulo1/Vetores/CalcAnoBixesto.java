import javax.swing.JOptionPane;

import java.util.*;

/* autor: Isaura



*/
public class CalcAnoBixesto
{
	public static void bissexto(int ano)
	{
		if(ano%4 ==0 && ano%100!=0)
		
				JOptionPane.showMessageDialog(null, ano+"E um ano bissexto");
		else

			JOptionPane.showMessageDialog(null, ano+"Nao e um ano bissexto");
		
			
	}
	public static void main(String[] args)
	{
		/* Para ser bissexto deve se o  ano e  multiplo de 4 e nao multiplo de 100
		 * 
		 */
		Scanner input = new Scanner(System.in);
		int year =Integer.parseInt(JOptionPane.showInputDialog("Insira o ano:"));
		bissexto(year);
		
		
	
		

	}

}
