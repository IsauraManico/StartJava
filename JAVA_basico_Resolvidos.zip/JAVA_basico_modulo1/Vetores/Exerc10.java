import java.util.Scanner;
/* autor: Isaura



*/
public class Exerc10
{

    public static  void main(String[] args)
    {
        Scanner in = new Scanner(System.in);

        int a[] =new int[10];
        int b[] = new int[10];

        for (int i=0;i<10;i++)
        {
            System.out.println("Digite os elementos:");
            a[i]= in.nextInt();

            b[i]=a[i]%2;
        }

        for (int x:b)
        {
            System.out.println("Os elementos de b:"+x);
        }
    }
}
