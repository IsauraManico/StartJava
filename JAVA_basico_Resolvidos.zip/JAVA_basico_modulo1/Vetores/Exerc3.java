import java.util.Scanner;
/* autor: Isaura



*/
public class Exerc3
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);

        int a[] = new int[15];
        int b[] = new int[15];
        int i=0;

        for(;i<15;i++)
        {
            System.out.println("Digite os valores no vetor: ");
            a[i]=in.nextInt();
            b[i]=a[i]*a[i];
        }

        for(int x:b)
        {
            System.out.println("Os valores ao dobro:"+x);
        }

    }
}
