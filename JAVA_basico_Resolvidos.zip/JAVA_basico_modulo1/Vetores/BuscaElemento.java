import java.util.Scanner;
//Usando varargs

//Com os varargs podemos passar infinitesimos valores

/* autor: Isaura



*/
public class BuscaElemento 
{
	static Scanner input = new Scanner(System.in);
	
	public static int busca(int elemento,Integer... A)
	{
		for(int i=0;i<A.length;i++)
		
			if(A[i] ==elemento)
				return i;
			return -1;
		
	}
	public static void main(String[] args)
	{
	
	
		int elem;
		
		System.out.println("Digite o elemento inteiro a procurar:");
		elem=input.nextInt();
		
		System.out.println("O elemento"+elem+"foi"+busca(elem,1,2,3,4,5,7,9));

	}

}
