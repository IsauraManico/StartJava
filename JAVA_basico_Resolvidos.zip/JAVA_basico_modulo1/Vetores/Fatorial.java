import java.util.Scanner;

public class Fatorial 
{
	static Scanner in=new Scanner(System.in);

	
	public static int fat(int a)
	{
		int fat=1;
		
		for(int i=1;i<=a;i++)
		{
			fat*=i;
		}
		return fat;
			
	}
	public static void main(String[] args) 
	{
			int n;
			System.out.println("Digite os elemento:");
			n=in.nextInt();
			
	
			System.out.println("O fatorial de:"+n+"="+fat(n));
	
		
	}

}
