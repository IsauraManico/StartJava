import java.util.Scanner;
/* autor: Isaura



*/
public class Exerc5
{
    public static  void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        int a[] = new int[10];
        int b[] = new int[10];

        int i=0;

        for (;i<10;i++)
        {
            System.out.println("Insira os elementos inteiros:");
            a[i]=in.nextInt();
            b[i]=a[i]*i;
        }

        for(int x:b)
        {
            System.out.println("Os elementos de b:"+x);
        }
    }
}
