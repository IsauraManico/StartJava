import java.util.Scanner;

public class Exerc15
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);

        int a[] = new int[10];
        int par=0;
        int impar=0;

        for (int i=0; i<a.length;i++)
        {
            System.out.println("Insira os elementos :");
            a[i]= input.nextInt();

            if(a[i]%2 == 0)
                par++;
            else if(a[i]%2== 1)
                    impar++;
        }

        System.out.println("Existem:"+par+"pares e"+impar+"impares");
    }
}
