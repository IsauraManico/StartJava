import java.util.Scanner;

public class Exerc13
{
    public static int sum(int[] a)
    {
        int s=0;

        for (int i=0;i<4;i++)
        {
            if(a[i]%5 ==0)
                 s+=a[i];
        }
        return s;
    }

    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        int a[] = new int[4];

        for (int i=0;i<4;i++)
        {
            System.out.println("Digite os elementos no vetor:");
            a[i]=input.nextInt();

        }
        System.out.println("A soma dos elementos:"+sum(a));


    }
}

