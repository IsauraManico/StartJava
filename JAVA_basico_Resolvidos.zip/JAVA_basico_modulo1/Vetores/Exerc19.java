import java.util.Scanner;

public class Exerc19
{
    static  Scanner input = new Scanner(System.in);

    public static  void ler(float [][]notasAluno)
    {
        for (int i=0 ;i<10;i++)
            for (int j=0;j<2;j++)
            {
                System.out.println("Insira duas notas para cada aluno:");
                notasAluno[i][j] = input.nextFloat();
            }
    }

    public static void imprimir(float [][] notasAluno)
    {
        for (int i=0 ;i<10;i++)
            for (int j=0;j<2;j++)
            {
                System.out.println("As notas do aluno: ["+i+"] ["+j+"] ="+notasAluno[i][j]);
            }

    }

    public static void main(String[] args)
    {
       float[][] notas= new float[10][2];
       ler(notas);
       imprimir(notas);




    }
}
