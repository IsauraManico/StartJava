import java.util.Scanner;
/* autor: Isaura



*/
public class Exerc4
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);

        int a[] = new int[15];
        double b[] = new double[15];
        int i=0;

        for(;i<15;i++)
        {
            System.out.println("Digite os valores no vetor: ");
            a[i]=in.nextInt();
            b[i]=Math.sqrt(a[i]);
        }

        for(double x:b)
        {
            System.out.println("Os valores ao dobro:"+x);
        }

    }
}

