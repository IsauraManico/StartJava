import  java.util.Scanner;

public class Exerc2
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        int a[]= new int[8];
        int b[]= new int[8];
        int i=0;

        for(;i<8;i++)
        {
            b[i]=1;
            System.out.println("Digite os elementos no vetor:");
            a[i]=in.nextInt();
            b[i]*=a[i]*2;
        }

       for(int x:b)
        {
            System.out.println(x);
        }
    }
}
