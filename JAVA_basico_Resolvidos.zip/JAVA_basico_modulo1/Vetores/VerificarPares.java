import javax.swing.JOptionPane;

public class VerificarPares {

	public static void main(String[] args)
	{
		int[]A =new int[]{1,2,3,4,5,6,7,8,9,10};
		String v="";
		
		for(int x:A)
		{
			System.out.println("Os elementos:"+x);
		}
		for(int i=0;i<A.length;i++)
		{
			if(A[i] %2 ==0)
				JOptionPane.showMessageDialog(null, "Sao todos pares");
			else
				JOptionPane.showMessageDialog(null,"Existem impares");
				break;
		}

	}

}
