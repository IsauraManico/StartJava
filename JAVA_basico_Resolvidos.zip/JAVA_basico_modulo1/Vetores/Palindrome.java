
/* autor: Isaura



*/
public class Palindrome 
{

	public static void main(String[] args)
	{
		
		//int[]A=new int[] {1,2,3,4,5,4,3,2,1}; //eh palindrome
		//Para ser palindrome, o primeiro elemento deve ser igual ao ultimo;
		//o segundo com o penultimo e assim sucessivamente
		//int []A = new int[] {1,2,3,4}; nao eh palindrome
		
		
		//usando varargs:
		palindrome(1,2,3,4,5,4,3,2,1);
		
		
	}
	
	public static void palindrome(Integer... A)
	{
	int i=0,j=0;
			int tam=A.length;
		for(;i<A.length;i++)
		{
			if(A[i]== A[tam-1])
			{
				A[j]=A[i];
				tam--;
				j++;
				
				System.out.println("EH palindrome");
			}
			else
				System.out.println("Nao ehh");
			
			
		}
	
	
	}

}
