import java.util.Scanner;

public class ReceberParImpar {

	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		
		System.out.println("Insira oo tamanho do vetor:");
		int tam=input.nextInt();
		
		int[] A = new int[tam];
		int[] B = new int[tam];
		
		for(int i=0;i<tam;i++)
		{
			System.out.println("Insira"+tam+" os elementos no vetor A:");
			A[i]=input.nextInt();
			
			if(A[i]%2 ==0)
				B[i]=1;
			else if(A[i]%2 ==1)
					B[i]=0;
		}
		
		for(int b:B)
		{
			System.out.println("Os elementos de B:"+b);
		}
		
		

	}

}
