import java.util.Scanner;

public class Exerc18
{
    public static void maiorMenor(int [] a){
           int pos2=0,pos1=0;
           int maior=-9999,menor=9999;

            for (int i=0;i<a.length;i++){
            if(a[i]>maior){
                maior=a[i];
                pos1=i;
            }

             if(a[i]<menor)
            {
                menor=a[i];
                pos2=i;
            }

        }
        System.out.println("O maior:"+maior+"pos:"+pos1);
        System.out.println("O menor:"+menor+"pos:"+pos2);

    }

    public static  void main(String[] args)
    {

        Scanner in = new Scanner(System.in);
        int maior;

        System.out.println("Insira o total de  idades:");
        int tot=in.nextInt();

        int a[] = new int[tot];

        for (int i=0;i<tot;i++)
        {
            System.out.println("Insira as idades:");
            a[i]=in.nextInt();



        }

        maiorMenor(a);


    }
}
