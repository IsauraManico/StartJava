import java.util.Scanner;

public class Exerc11
{

    public static int quantidade(int[]a)
    {
        int q=0;
        for(int i=0;i<10;i++)
        {
            if(a[i]%2 ==0)
                q++;

        }
        return q;
    }
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        int a[] = new int[10];

        for(int i=0;i<10;i++)
        {
            System.out.println("Insira os elementos no vetor:");
            a[i]=in.nextInt();
        }
        System.out.println("Os vetores tem"+quantidade(a)+"quantidades pares");
    }
}
