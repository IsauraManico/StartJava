public class ExercVet20
{
    public static void main(String[] args)
    {

    }
}
