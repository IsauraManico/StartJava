
public class Tabuada {

	public static void main(String[] args)
	{
		String r="";
		
		for(int i=1;i<=12;i++)
			for(int j=1;j<=12;j++)
			{
				r+="["+i+"*"+j+"]="+(i*j)+"\n";
			}
		
		System.out.println(r);

	}

}
