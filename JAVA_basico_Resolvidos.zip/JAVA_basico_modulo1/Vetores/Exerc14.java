import java.util.Scanner;

public class Exerc14
{
    public static float med(int[] a)
    {
        float s=0;

        for (int i=0;i<a.length;i++)
        {
            if(a[i]%2 ==1)
                s+=a[i];
        }
        return s/a.length;
    }

    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        int a[] = new int[4];

        for (int i=0;i<4;i++)
        {
            System.out.println("Digite os elementos no vetor:");
            a[i]=input.nextInt();

        }
        System.out.println("A soma dos elementos:"+med(a));


    }
}


