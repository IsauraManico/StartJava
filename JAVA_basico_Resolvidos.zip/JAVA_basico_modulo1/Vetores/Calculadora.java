import java.util.Scanner;

/* autor: Isaura



*/
public class Calculadora 
{
	static Scanner input = new Scanner(System.in); //leitura por teclado
	
	//AS funcoes que realizam as operacoes
	
	public static float sum(float a, float b)
	{
		return a+b;
	}
	
	public static float produto(float a, float b)
	{
		return a*b;
	}
	public static float div(float a, float b)
	{
		return a/b;
	}
	public static float resto(float a, float b)
	{
		return a%b;
	}
	public static float dife(float a, float b)
	{
		return a-b;
	}
	
	
	
	public static void main(String[] args)
	{
		
		
		float n1,n2;
		System.out.println("Digite o primeiro numero:");
		n2=input.nextInt();
		System.out.println("Digite o segundo numero:");
		n1=input.nextInt();
		
		System.out.println("Insira a operacao: +,-,/,*,%");
		String op=input.next();
		
		switch(op)
		{
		case"+":
			System.out.println(+n1+"+"+"="+n2+"="+sum(n1,n2));
			break;
		case "-":
			System.out.println(+n1+"-"+"="+n2+"="+dife(n1,n2));
			break;
		case "*":
			System.out.println(+n1+"*"+"="+n2+"="+produto(n1,n2));
			break;
		case "%":
			System.out.println(+n1+"%"+"="+n2+"="+resto(n1,n2));
			break;
		case "/":
			System.out.println(+n1+"/"+"="+n2+"="+div(n1,n2));
			break;
		default:
			System.out.println("Operador invalido");
			
		}
		
		

	}

}
