import  java.util.Scanner;
/* autor: Isaura



*/
public class Exerc7
{
    public static  void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        System.out.println("Digite a quantidade de elementos para os vetores:");
        int n=in.nextInt();
        int a[] = new int[n];
        int b[]= new int[n];
        int c[] = new int[n];
        int i=0;
        int s=0;

        for(;i<n;i++)
        {
            System.out.println("Digite os elementos do primeiro vetor:");
            a[i]=in.nextInt();
            System.out.println("Digite os elementos do segundo vetor:");
            b[i]=in.nextInt();
            s+=a[i]-b[i];

        }

        System.out.println("A soma dos vetores:"+s);
    }
}
