import java.util.Scanner;
/* autor: Isaura



*/
public class Exerc9
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);

        int a[] =new int[10];
        int b[] = new int[10];
        double c[] = new double[10];

        for(int i=0;i<10;i++)
        {
            System.out.println("Digite os elemetos no primeiro vetor:");
            a[i]=in.nextInt();
            System.out.println("Digite os elemnentos no segundo vetor:");
            b[i]= in.nextInt();

            c[i]=(float) a[i]/b[i];

        }

        for (double x:c)
        {
            System.out.println("Os elentos divididos sao:"+x);
        }
    }


}
