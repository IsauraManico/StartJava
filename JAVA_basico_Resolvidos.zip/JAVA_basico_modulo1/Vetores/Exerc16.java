import java.util.Scanner;

public class Exerc16
{

    public static int sum(int[]a)
    {
        int s=0;

        for (int i=0;i<a.length;i++)
        {
            if(a[i]<15)
                s+=a[i];
        }
        return s;
    }
    public static int igual(int [] a)
    {
        int s=0;

        for (int i=0;i<a.length;i++)
        {
            if(a[i] ==15)
                s++;
        }
        return s;

    }

    public static float media(int []a)
    {
        float med=0;

        for (int i=0;i<a.length;i++)
        {
            med+=a[i];
        }
        return med/a.length;
    }
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        int a[] = new int[10];
        int i=0;

        for(;i<a.length;i++)
        {
            System.out.println("Insira os elementos:");
            a[i]=in.nextInt();
        }
        System.out.println("A soma dos elementos inferiores a 15:"+sum(a));
        System.out.println("A quantidade dos elementos iguais a 15:"+igual(a));
        System.out.println("A media dos elementos inferiores a 15:"+media(a));


    }
}
