
package sum;

/**
 *
 * @author isaura
 */
public class Soma
{
    public static int soma(int i, int[] a)
    {
        if(i>=a.length)
            return 0;
        
            return a[i]+soma(i+1,a);
        
    }
    
}
