
package fatorial;

/**
 *
 * @author isaura
 */
public class Fatorial
{
    public static int fatorial(int x)
    {
        if(x ==0 || x==1)
            return 1;
        return x*fatorial(x-1);
    }
}
