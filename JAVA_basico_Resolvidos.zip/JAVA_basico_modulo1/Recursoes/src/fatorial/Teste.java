
package fatorial;

/**
 *
 * @author isaura
 */

import javax.swing.JOptionPane;

public class Teste 
{
    public static void main(String[] args)
    {
        int x =Integer.parseInt(JOptionPane.showInputDialog("Insira um inteiro:"));
        
        JOptionPane.showMessageDialog(null, "O fatorial de "+x+":"+Fatorial.fatorial(x));
    }
    
}
