
package potencia;

import javax.swing.JOptionPane;

/**
 *
 * @author isaura
 */
public class Potencia 
{
    public static int potIterativo(int base,int expo)
    {
    
        int p=1;
            if(expo == 0)
            return 1;
            if(expo ==1)
                return base;
            else
            {
                if(expo > 0){
                for(int i=1;i<=expo;i++)
                {
                    p*=base;
                }
                return p;
                }
                else
                {
                     for(int i=1;i<=expo;i++)
                     {
                        p*=base;
                     }
                   
                     JOptionPane.showMessageDialog(null, "A potencia 1/"+p);
                      return p;
                  }
                    
                   
                   
                }
            }


    
   
    
    
    
    
}
    
    
        

    

