
package potencia;

import javax.swing.JOptionPane;

/**
 *
 * @author isaura
 */
public class Teste 
{
    public static void main(String[] args)
    {
       int base =Integer.parseInt(JOptionPane.showInputDialog("Insira a base:"));
       int expoente =Integer.parseInt(JOptionPane.showInputDialog("Insira oexpoente:"));
       
       //JOptionPane.showMessageDialog(null,Potencia.potIterativo(base, expoente));
        System.out.println(PotenciaRec.potRec(base, expoente, 1));
    }
    
}
