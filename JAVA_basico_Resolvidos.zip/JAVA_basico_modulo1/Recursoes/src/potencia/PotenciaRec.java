
package potencia;

/**
 *
 * @author isaura
 */
public class PotenciaRec 
{
    public static int potRec(int base,int expo,int i)
    {
        if(expo ==0)
        
              return 1;
     else
        {
            if(i>expo)
                return 1;
        }
        return base*potRec(base,expo,i+1);
            
       
    } 
}
