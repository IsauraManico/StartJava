import java.util.Scanner;

public class ConvCelsiosFarenheit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		System.out.println("Insira o valor em grau celsius ");
		float c =in.nextFloat();
		float f=(9c+5*32)/5
		System.out.println("O seu equivalente a farenheit:s"+f);


	}

}
