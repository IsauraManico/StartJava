
package comInteiros;

import javax.swing.JOptionPane;

/**
 *
 * @author isaura
 */
public class N_Prim_Impares
{
    public static void main(String[] args) 
    {
        int n = Integer.parseInt(JOptionPane.showInputDialog("Insira o inteiro"));
        int i=0;
        
        for(;i<=n;i++)
        {
            if(i%2 == 1)
                
                    System.out.println(i);
              
                
        }
       
        
        
        
    }
    
}
