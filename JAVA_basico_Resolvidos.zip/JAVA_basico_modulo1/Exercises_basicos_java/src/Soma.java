import java.util.Scanner;

public class Soma {
	
	public static int soma(int numero1, int numero2)
	{
		return numero1+numero2;
	}
	

	public static void main(String[] args)
	{
		Scanner in = new Scanner(System.in);
		
		System.out.println("Digite o primeiro inteiro:");
		int n1=in.nextInt();
		System.out.println("Digite o segundo inteiro:");
		int n2=in.nextInt();
		
		System.out.println("A soma entre:"+n1+"+"+n2+"="+(soma(n1,n2)));
		
		// TODO Auto-generated method stub

	}

}
