
package comInteiros;

/**
 *
 * @author isaura
 */

import javax.swing.JOptionPane;

public class TesteQuadrado
{
    public static void main(String[] args) 
    {
    
        int x = Integer.parseInt(JOptionPane.showInputDialog("Insira um inteiro:"));
        
        Quadrados.quadrados(x);
        
        
    }
    
}
