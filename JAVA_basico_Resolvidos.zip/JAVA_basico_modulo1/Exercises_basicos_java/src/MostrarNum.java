import java.util.Scanner;


public class MostrarNum {

	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		
		System.out.println("Digite um inteiro:");
		int num= input.nextInt();
		
		System.out.println(num);
		// TODO Auto-generated method stub

	}

}
