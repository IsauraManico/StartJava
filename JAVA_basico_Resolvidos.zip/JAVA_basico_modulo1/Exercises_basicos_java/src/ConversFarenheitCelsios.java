import java.util.Scanner;

public class ConversFarenheitCelsios {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				Scanner in = new Scanner(System.in);
				System.out.println("Insira o valor em grau farenheit:");
				float f =in.nextFloat();
				float c =(5*(f-32)/9);
				System.out.println("O seu equivalente a celsios"+c);


	}

}
