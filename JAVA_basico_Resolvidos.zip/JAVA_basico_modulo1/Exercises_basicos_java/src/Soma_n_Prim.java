
package comInteiros;

/**
 *
 * @author isaura
 */
import javax.swing.JOptionPane;

public class Soma_n_Prim 
{
    public static void main(String[] args) 
    {
        int n=Integer.parseInt(JOptionPane.showInputDialog("Insira o inteiro:"));
        int s=0;
        
        for(int i=0;i<=n;i++)
        {
            s+=i;
            System.out.println("A soma dos"+i+":"+s);
        }
        
    }
}
