import java.util.Scanner;

public class PesoPescador {

	public static void main(String[] args) {
	
		Scanner in = new Scanner(System.in);
		System.out.println("Digite o peso:");
		float peso =in.nextFloat();
		int excesso=0,multa=0;
		
		if(peso>=50)
		{
			multa=4;
			excesso=4;
		}
			
			System.out.println("Execesso "+excesso+"Multa"+multa+"peso"+peso);
		

	}

}
