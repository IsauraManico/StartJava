import java.util.Scanner;

public class Calculos {

	public static void main(String[] args) 
	{
		Scanner in = new Scanner(System.in);
		
		System.out.println("Insira o primeiro inteiro:");
		int n1 = in.nextInt();
		System.out.println("Insira o segundo inteiro:");
		int n2 = in.nextInt();
		System.out.println("Insira um real:");
		float n3 = in.nextFloat();
		
		System.out.println("O produto do dobro do primeiro com a metade do seg::"+((n1*n1))*(n1/2));
		System.out.println("A soma do triplo do prim com terc"+((n1*n1*n1)+n3));
		System.out.println("O terceiro ao cubo"+(n3*n3*n3));
		

	}

}
