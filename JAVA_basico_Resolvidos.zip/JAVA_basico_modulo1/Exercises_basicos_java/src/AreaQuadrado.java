import java.util.Scanner;

public class AreaQuadrado {
	
	

	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		System.out.println("Digite a largura:");
		int largura=in.nextInt();
		int area=largura*largura;
		
		System.out.println("O dobro da area do quadradro:"+(area*area));
		// TODO Auto-generated method stub

	}

}
