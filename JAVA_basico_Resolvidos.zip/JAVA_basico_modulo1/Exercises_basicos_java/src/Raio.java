import java.util.Scanner;

public class Raio {

	public static void main(String[] args)
	{
		Scanner in = new Scanner(System.in);
		
		System.out.println("Digite o raio:");
		float raio =in.nextFloat();
		System.out.println("A area:"+(2*raio));
		// TODO Auto-generated method stub
		

	}

}
