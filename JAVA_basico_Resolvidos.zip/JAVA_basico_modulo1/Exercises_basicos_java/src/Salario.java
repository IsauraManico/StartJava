import java.util.Scanner;

public class Salario {

	public static void main(String[] args)
	{
		Scanner in = new Scanner(System.in);
		
		System.out.println("Quanto ganhas por hora:");
		int valor = in.nextInt();
		System.out.println("Por quantas horas trabalhas:");
		int nHoras = in.nextInt();
		float salario=valor*nHoras*31;
		
		System.out.println("Ganhas mensalmente:"+salario);
		
		// TODO Auto-generated method stub

	}

}
