import java.util.Scanner;

public class MetrosPCmetros {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		Scanner in = new Scanner(System.in);
		System.out.println("Digite o valor em metro:");
		float metro=in.nextFloat();
		System.out.println(metro+"m equivale a:"+(metro*100));

	}

}
