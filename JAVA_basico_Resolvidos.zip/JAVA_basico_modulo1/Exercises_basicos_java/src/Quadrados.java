
package comInteiros;

/**
 *
 * @author isaura
 */
public class Quadrados 
{
    public static void quadrados(int x)
    {
        for(int i=0;i<=x;i++)
            System.out.println("Qudrado de "+i+":"+(i*i));
        
    }
    
}
