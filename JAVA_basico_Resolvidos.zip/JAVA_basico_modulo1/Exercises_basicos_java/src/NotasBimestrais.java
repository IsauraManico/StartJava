import java.util.Scanner;

public class NotasBimestrais {
	
	public static float  media(float nota1,float nota2,float nota3,float nota4)
	{
		return (nota1+nota2+nota3+nota4)/4;
	}

	public static void main(String[] args)
	{
		Scanner in = new Scanner(System.in);
		
		System.out.println("Digite a primeira nota:");
		float n1=in.nextFloat();
		System.out.println("Digite a segunda nota:");
		float n2 = in.nextFloat();
		System.out.println("Digite a terceira nota:");
		float n3=in.nextFloat();
		System.out.println("Digite a quarta nota:");
		float n4=in.nextFloat();
		
		System.out.println("A media bimestral:"+media(n1,n2,n3,n4));
		// TODO Auto-generated method stub

	}

}
