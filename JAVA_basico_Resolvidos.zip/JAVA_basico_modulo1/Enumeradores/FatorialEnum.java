package WorkEnum;

import java.util.Scanner;

public class FatorialEnum 
{
	
	static Scanner input = new Scanner(System.in);
	
	enum Mult
	{
		
		
		FATO(0) {
			@Override
			public int fatorial(int x) 
			{
				int f=1;
				
				if(x==0 && x==1)
					return 1;
				else
				{
					for(int i=1;i<=x;i++)
						f*=i;
					return f;
				}
				
				
			}
		};
		
		private int i;
		
		Mult(int i)
		{
			this.i=i;
		}
		
		public abstract int fatorial(int x);
	}

	public static void main(String[] args) 
	{
		System.out.println("Insira o inteiro:");
		int x=input.nextInt();
		
		for(Mult m:Mult.values())
		{
			System.out.println("O fatorial de:"+x+"="+m.fatorial(x));
		}

	}

}
