package WorkEnum;

public class Calculadora 
{
	enum Operacao
	{
		SOMA("+") {
			@Override
			public double execucaoOperac(double x, double y) {
				
				return x+y;
			}
		},SUB("-") {
			@Override
			public double execucaoOperac(double x, double y) {
				
				return x-y;
			}
		},DIV("/") {
			@Override
			public double execucaoOperac(double x, double y) {
				
				return x/y;
			}
		},MULT("*") {
			@Override
			public double execucaoOperac(double x, double y) {
				
				return x*y;
			}
		},RESTO("%") {
			@Override
			public double execucaoOperac(double x, double y) {
				
				return x%y;
			}
		},EXPO("x^y") {
			@Override
			public double execucaoOperac(double x, double y) {
				double pot=1.0;
				
				for(int i=1;i<=y;i++)
					pot*=x;
				return pot;
			}
		};
		
		private String simb;
		
		Operacao(String simb)
		{
			this.simb =simb;
		}
		
		public void setSimb(String simb)
		{
			this.simb=simb;
		}
		public String getSimb()
		{
			return this.simb;
		}
		
		public abstract double execucaoOperac(double x, double y);
	}

	public static void main(String[] args) 
	{
			//teste
		double x =2.0;
		double y =3.0;
		
		System.out.println(x+"x:");
		System.out.println(x+"y:");
		
			for(Operacao o: Operacao.values())
			{
				
				System.out.println(o.execucaoOperac(x, y));
				System.out.println(o.toString());
				
			}
	}

}
